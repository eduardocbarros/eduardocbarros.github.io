#!/bin/bash
node scrape.js https://docs.microsoft.com/en-gb/azure/
node scrape.js https://azure.microsoft.com/en-gb/patterns/styles/glyphs-icons/
#node scrape.js https://azure.microsoft.com/en-us/solutions/

# node scrape.js https://azure.microsoft.com/en-us/overview/azure-vs-aws
# node scrape.js https://azure.microsoft.com/en-us/overview/ai-platform
# node scrape.js https://azure.microsoft.com/en-us/services/kubernetes-service
# node scrape.js https://azure.microsoft.com/en-us/overview/containers
# node scrape.js https://azure.microsoft.com/en-us/services/devops
# node scrape.js https://azure.microsoft.com/en-us/services/active-directory
# node scrape.js https://azure.microsoft.com/en-us/services/cognitive-services/directory/
# node scrape.js https://azure.microsoft.com/en-us/services/automation/
# node scrape.js https://azure.microsoft.com/en-us/services/iot-central/
# node scrape.js https://azure.microsoft.com/en-us/services/time-series-insights/
# node scrape.js https://azure.microsoft.com/en-us/resources/
# node scrape https://azure.microsoft.com/en-us/services/logic-apps/