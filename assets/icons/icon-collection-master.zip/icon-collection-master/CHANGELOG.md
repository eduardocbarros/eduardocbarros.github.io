## Oct 30th 2020
- v2 of official icon set from the Azure Architecture Center with about forty new icons
- A few icons from the AKS portal in other/kube-*


## August 1st 2020
- Reorg and rename!
- Added the new official icon set from the Azure Architecture Center
- Renamed the previous 'azure-icons' set to 'azure-cds', and the above Azure Architecture Center icons are now called 'azure-icons'. This is confusing, sorry!
- Removed the 'cloud-old' set, no one should need this now.


## July 26th 2020
- HUGE UPDATE! 😁
- New 'Cloud Design Studio' icon set added with all official Azure icons in new style
- All Azure Docs icons refreshed with the new Azure branding / style
- All Azure Patterns icons refreshed with the new Azure branding / style
- Azure Patterns icons now have names!